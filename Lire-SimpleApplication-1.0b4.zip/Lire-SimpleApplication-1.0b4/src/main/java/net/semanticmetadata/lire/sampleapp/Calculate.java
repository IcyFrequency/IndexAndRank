package net.semanticmetadata.lire.sampleapp;

/**
 * Created by SherWorkHorse on 18.10.2016.
 */
public class Calculate{

    public Calculate(){
        super();
    }
    public void decideOne(){
        System.out.println("\n");
    }
}
